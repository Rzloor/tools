<?php
$config->editor->sort[] = 'model.php';
$config->editor->sort[] = 'control.php';
$config->editor->sort[] = 'view';
$config->editor->sort[] = 'lang';
$config->editor->sort[] = 'config.php';
$config->editor->sort[] = 'js';
$config->editor->sort[] = 'css';
$config->editor->sort[] = 'ext';

$config->editor->extSort[] = 'model';
$config->editor->extSort[] = 'control';
$config->editor->extSort[] = 'view';
$config->editor->extSort[] = 'lang';
$config->editor->extSort[] = 'js';
$config->editor->extSort[] = 'css';
$config->editor->extSort[] = 'config';

