CKEDITOR.editorConfig = function( config ) {
	config.toolbarGroups = [
		// { name: 'clipboard', groups: [ 'clipboard', 'undo' ] },
		// { name: 'editing', groups: [ 'find', 'selection', 'spellchecker', 'editing' ] },
		// { name: 'links', groups: [ 'links' ] },
		{ name: 'insert', groups: [ 'insert' ] },
        { name: 'paragraph', groups: [ 'list', 'indent', 'blocks', 'align', 'bidi', 'paragraph' ] },
        // { name: 'forms', groups: [ 'forms' ] },
		// { name: 'tools', groups: [ 'tools' ] },
		// { name: 'document', groups: [ 'mode', 'document', 'doctools' ] },
		// { name: 'others', groups: [ 'others' ] },
		// '/',
		{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
		{ name: 'styles', groups: [ 'styles' ] },
		{ name: 'colors', groups: [ 'colors' ] },
		// { name: 'about', groups: [ 'about' ] }
	];

	config.removeButtons = 'Subscript,Superscript,About,Source,SpecialChar,Unlink,Link,Anchor,PasteText,PasteFromWord,Table,Strike,Blockquote';
    config.removeDialogTabs = 'image:advanced;image:Link';//隐藏超链接与高级选项
    config.extraPlugins = 'uploadimage'
    config.filebrowserImageUploadUrl = 'http://cstwo.bai08.com/api/live/uploadFiles?action=uploadimage&live_k=1'
    config.language = 'zh-cn';/*将编辑器的语言设置为中文*/
    config.image_previewText = '';/*去掉图片预览框的文字*/

};